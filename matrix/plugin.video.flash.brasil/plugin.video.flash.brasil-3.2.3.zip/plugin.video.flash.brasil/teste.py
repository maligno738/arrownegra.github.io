import requests

url = 'https://pastebin.com/raw/cbwadFyK'
response = requests.get(url)

conteudo = response.text
print(conteudo)
