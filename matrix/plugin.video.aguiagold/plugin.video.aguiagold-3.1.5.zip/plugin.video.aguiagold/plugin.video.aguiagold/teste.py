import requests

url = 'https://raw.githubusercontent.com/kodishmediacenter/tralhasdakodish/master/server-teste'
response = requests.get(url)

conteudo = response.text
print(conteudo)
