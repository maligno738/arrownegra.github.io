import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLngtY29kZXM=')

name = b.b64decode('RGFyayBTaWRlIFRW')

host = b.b64decode('aHR0cDovL2xvYWQtYmFsYW5jZS5pbmZv')

port = b.b64decode('ODA=')